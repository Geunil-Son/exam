package egovframework.example.faq.service;

import egovframework.example.common.Criteria;
import egovframework.example.emp.service.EmpVO;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class FaqVO extends Criteria {

//	FNO	NUMBER
//	TITLE	VARCHAR2(255 BYTE)
//	CONTENT	VARCHAR2(255 BYTE)
//	INSERT_TIME	VARCHAR2(255 BYTE)
//	UPDATE_TIME	VARCHAR2(255 BYTE)
	
	private int fno;
	private String title;
	private String content;
	private String insertTime;
	private String updateTime;
}
