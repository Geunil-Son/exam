package com.simplecoding.simpledms.qna.service;

import com.simplecoding.simpledms.qna.dto.QnaDto;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@Log4j2
@SpringBootTest
@EnableJpaAuditing
class QnaServiceTest {
    //    테스트 시 필드 DI
    @Autowired
    QnaService qnaService;

    @Test
    void selectQnaList() {
        //        1) 테스트 준비
        String searchKeyword = "";
//      사용법: PageRequest.of(현재페이지번호, 화면에보이는개수)
        Pageable pageable = PageRequest.of(0, 3);
//        2) 실행
        Page<QnaDto> page=qnaService.selectQnaList(searchKeyword, pageable);
//        3) 결과 확인
        log.info(page.getContent()); // 결과 배열 확인

    }
}