package egovframework.example.exam;

public class A {

//	[이론]
//			1. 스프링 MVC 디자인 패턴에 대해서 설명해주세요
			
//	MVC는 데이터처리(model), 사용자 요청 처리(controller), 화면출력 (view)
//	를 나누어 웹 애플리케이션을 구조적으로 관리하기 위한 디자인 패턴임


}
