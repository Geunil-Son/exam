package egovframework.example.exam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import egovframework.example.dept.service.DeptService;
import lombok.extern.log4j.Log4j2;

public class B {
	
//	2. 아래 코드 중 누락된 부분을 추가하세요

	
	@Log4j2
	@Controller
	public class DeptController {
//	        서비스 가져오기
			@Autowired
	        private DeptService deptService; 
	...
	}

}
