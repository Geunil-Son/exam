package com.simplecoding.simpledms.exam;

public class B {
//    * 지시한 사항 외에 코딩은 자유롭게 하세요
//    2. 생성자 DI와 컨트롤러를 만들려고 합니다.
//    아래 코드 중 누락된 부분을 추가하세요


//    @RequiredArgsConstructor
//    @Log4j2
//    @Controller
//    public class DeptController {
//        //      생성자 DI
//        private final DeptService deptService;
//
//        //        서비스 가져오기
//        private DeptService deptService;

//    }
}
