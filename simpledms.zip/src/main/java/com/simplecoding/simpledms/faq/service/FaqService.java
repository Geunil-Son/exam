package com.simplecoding.simpledms.faq.service;

import com.simplecoding.simpledms.common.ErrorMsg;
import com.simplecoding.simpledms.common.MapStruct;
import com.simplecoding.simpledms.dept.dto.DeptDto;
import com.simplecoding.simpledms.dept.entity.Dept;
import com.simplecoding.simpledms.faq.dto.FaqDto;
import com.simplecoding.simpledms.faq.entity.Faq;
import com.simplecoding.simpledms.faq.repository.FaqRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Service
@RequiredArgsConstructor
public class FaqService {
    //    생성자 DI
    private final FaqRepository faqRepository;
    private final MapStruct mapStruct;       // 복사 라이브러리
    private final ErrorMsg errorMsg;  // 에러메세지 화면표시 클래스


    //    전체조회: 페이징 + DTO 리턴
//    TODO: 조회: DB 결과 -> 엔티티클래스 저장 -> DTO 복사 -> DTO 를 화면 표시(추천)
//      예) dto.fno=엔티티.fno 코딩하는것: 값 복사 => 길어져서 : 복사 라이브러리 사용(MapStruct)
    public Page<FaqDto> selectFaqList(String searchKeyword,
                                      Pageable pageable) {
        Page<Faq> page = faqRepository.selectFaqList(searchKeyword, pageable);
//        자바의 stream(자동 반복: 배열의 끝까지 코드를 자동 반복)
//        람다식: long sum(int a){return a+1;} : a->a+1
        return page.map(data -> mapStruct.toDto(data));
    }

    //    추가: save() : 기본메소드(sql 코딩 필요없음)
//    조회: DB결과 -> 엔티티 저장 -> DTO 복사 -> 화면표시
//    추가: 화면입력 -> DTO 저장 -> 엔티티 복사 -> DB 저장
    public void save(FaqDto faqDto) {
        Faq faq = mapStruct.toEntity(faqDto);
        faqRepository.save(faq);

    }

    //    TODO: 상세조회: JPA 기본메소드(sql 작성 없음)
//     mapStruct: (필드에서 3년정도 된 것들 위주로): 추천(성능)
//     modelMapper : (성능 낮음)
    public FaqDto findById(long fno) {
        Faq Faq = faqRepository.findById(fno)
                .orElseThrow(() -> new RuntimeException(errorMsg.getMessage("errors.not.found")));
        return mapStruct.toDto(Faq);
    }

    @Transactional
    public void updateFromDto(FaqDto faqDto) {
//        더티 체킹 수정 코딩법: 1) 상세조회(DB값)
        Faq faq = faqRepository.findById(faqDto.getFno())
                .orElseThrow(() -> new RuntimeException(errorMsg.getMessage("errors.not.found")));
//                            2) setter 이용해서 값 수정(dto의 값을 entity로 수정)
        mapStruct.updateFromDto(faqDto, faq);
    }

    //    삭제
    public void deleteById(long fno) {
        faqRepository.deleteById(fno);
    }


}
