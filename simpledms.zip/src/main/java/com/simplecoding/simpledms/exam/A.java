package com.simplecoding.simpledms.exam;

public class A {

//    TODO : 1. 스프링의 DI, IOC, AOP에 대해서 설명해주세요

//    DI는 의존성 주입임. 어떤 객체가 필요한 객체를 스프링이 자동으로 주입해주는거임.
//    IOC는 제어의 역전으로 제어권을 개발자가 아니라 스프링이 갖게 하는것임.
//    AOP는 관점 지향 프로그래밍임. 공통 기능을 핵심 로직과 분리하는 방식임.
}
