/**
 * 
 */
package exam;


import java.util.Arrays;
import java.util.Scanner;

/**
 * @author user
 * 3번문제
 * 첫줄에 숫자의 총개수 N이 입력됩니다. 
   2줄에 N개의 숫자가 랜덤하게 입력됩니다. 
   오름차순 정렬해서 화면에 표시하는 코드를 작성하세요
 */
public class S3 {
 public static void main(String[] args) {
	
	Scanner scanner = new Scanner(System.in);
	int a = scanner.nextInt();
	int [] b = new int[a];

	
	for (int i = 0; i < a; i++) {
		Arrays.sort(b);
		System.out.println(Arrays.toString(b));
//더 이상 진행이 안됩니다..
	}
 }
}
