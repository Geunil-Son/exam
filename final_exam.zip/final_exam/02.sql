
-- [실습]
--  지시한 사항 외에 코딩은 자유롭게 하세요
-- 2. dept 전체조회를 하려고 합니다.
--   querydsl 로 작성하세요

POST /department/_search
{
  "query": {
    "match_all": {}
  }
}